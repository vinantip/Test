#!/bin/sh

#rm -f *.in */*.in */*/*.in */*/*/*.in
autoreconf --install --symlink --force
